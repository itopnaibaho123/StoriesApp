package com.dicoding.picodiploma.loginwithanimation.model

data class StoryModel(
    val name: String,
    val photoUrl: String,
    val id: String,
)