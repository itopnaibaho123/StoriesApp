package com.dicoding.picodiploma.loginwithanimation.model

data class UserModel(
    val name: String,
    val userId: String,
    val token: String,
)